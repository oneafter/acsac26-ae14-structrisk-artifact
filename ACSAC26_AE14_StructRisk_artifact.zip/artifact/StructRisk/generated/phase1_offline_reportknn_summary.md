# StackDedup-kNN Baseline Summary

## Primary Metrics
- `HighRisk@5=3`
- `HighRisk@10=4`
- `NDCG@5=0.5296`
- `NDCG@10=0.4171`
- `Rank-to-First-HighRisk=2`
- `Effort-to-First-HighRisk=16.28`

## Top-10 Findings
- `1`. `OpenCC::finding::96413572` risk=0 score=0.6053 neighbors=['soloud::finding::06044241', 'raylib::finding::68499575', 'lily::finding::19530969']
- `2`. `binaryen::finding::36473443` risk=3 score=0.6053 neighbors=['soloud::finding::06044241', 'raylib::finding::68499575', 'lily::finding::19530969']
- `3`. `openbabel::finding::70823212` risk=3 score=0.6053 neighbors=['soloud::finding::06044241', 'raylib::finding::68499575', 'lily::finding::19530969']
- `4`. `squirrel::finding::11477017` risk=3 score=0.6004 neighbors=['soloud::finding::06044241', 'soloud::finding::79418467', 'raylib::finding::68499575']
- `5`. `xlnt::finding::17141216` risk=0 score=0.6004 neighbors=['soloud::finding::06044241', 'soloud::finding::79418467', 'raylib::finding::68499575']
- `6`. `xlnt::finding::61192659` risk=0 score=0.6004 neighbors=['soloud::finding::06044241', 'soloud::finding::79418467', 'raylib::finding::68499575']
- `7`. `xlnt::finding::77280579` risk=3 score=0.6004 neighbors=['soloud::finding::06044241', 'soloud::finding::79418467', 'raylib::finding::68499575']
- `8`. `xlnt::finding::93136174` risk=0 score=0.6004 neighbors=['soloud::finding::06044241', 'soloud::finding::79418467', 'raylib::finding::68499575']
- `9`. `mruby::finding::69853620` risk=0 score=0.5995 neighbors=['wren::finding::49674825', 'wren::finding::94781489', 'raylib::finding::68499575']
- `10`. `ChaiScript::finding::11793711` risk=0 score=0.5265 neighbors=['lily::finding::96276758', 'soloud::finding::44702261', 'soloud::finding::79418467']
