# Artifact-Completeness Baseline Summary

## Primary Metrics
- `HighRisk@5=2`
- `HighRisk@10=3`
- `NDCG@5=0.3008`
- `NDCG@10=0.2614`
- `Rank-to-First-HighRisk=3`
- `Effort-to-First-HighRisk=26.4`

## Top-10 Findings
- `1`. `binaryen::finding::79565612` risk=0 score=5.9852 report=`exact` support=`96` cmdline=`afl_output_emscripten/default/cmdline`
- `2`. `binaryen::finding::56457462` risk=0 score=5.8845 report=`exact` support=`498` cmdline=`afl_output_wasm_opt/default/cmdline`
- `3`. `wabt::finding::73259399` risk=3 score=5.7594 report=`exact` support=`36` cmdline=`fuzz_out/master/cmdline`
- `4`. `wabt::finding::93101875` risk=0 score=5.7344 report=`exact` support=`34` cmdline=`fuzz_out/master/cmdline`
- `5`. `wabt::finding::28115182` risk=3 score=5.6498 report=`exact` support=`28` cmdline=`fuzz_out/master/cmdline`
- `6`. `wabt::finding::02015559` risk=0 score=5.1233 report=`exact` support=`8` cmdline=`fuzz_out/master/cmdline`
- `7`. `binaryen::finding::60970463` risk=0 score=5.0102 report=`exact` support=`6` cmdline=`afl_output_wasm_opt/default/cmdline`
- `8`. `binaryen::finding::75722786` risk=0 score=5.0102 report=`exact` support=`6` cmdline=`afl_output_wasm_opt/default/cmdline`
- `9`. `wasm3::finding::30113371` risk=3 score=4.9926 report=`exact` support=`741` cmdline=`build-asan/cmdline`
- `10`. `binaryen::finding::42194263` risk=0 score=4.9595 report=`exact` support=`4` cmdline=`afl_output_emscripten/default/cmdline`
