# MAGMA Crash-Backed Component Summary

- Raw artifacts: `120`
- Deduplicated findings: `46`
- Projects: `7`
- HIGH-or-CRITICAL positives: `30`
- Projects with reports: `7`

## Project Summary

- `libpng`: findings=4, positives=1, avg_support=3.0, avg_site_anchor=0.5, avg_locality=0.85
- `libtiff`: findings=9, positives=6, avg_support=2.56, avg_site_anchor=0.5, avg_locality=0.85
- `libxml2`: findings=6, positives=5, avg_support=2.67, avg_site_anchor=0.5, avg_locality=0.85
- `openssl`: findings=4, positives=3, avg_support=2.0, avg_site_anchor=0.5, avg_locality=0.85
- `php`: findings=3, positives=3, avg_support=3.0, avg_site_anchor=0.5, avg_locality=0.85
- `poppler`: findings=12, positives=5, avg_support=2.42, avg_site_anchor=0.5, avg_locality=0.85
- `sqlite3`: findings=8, positives=7, avg_support=2.88, avg_site_anchor=0.5, avg_locality=0.85

## Example Cards

- `libpng::finding::46928917` (libpng): bugs=AAH001, cves=CVE-2018-13785, asan=DEADLYSIGNAL
- `libpng::finding::56002180` (libpng): bugs=AAH007, cves=n/a, asan=DEADLYSIGNAL
- `libpng::finding::62769382` (libpng): bugs=AAH008, cves=CVE-2013-6954, asan=DEADLYSIGNAL
- `libpng::finding::67434740` (libpng): bugs=AAH003, cves=CVE-2015-8472, asan=DEADLYSIGNAL
- `libtiff::finding::20831159` (libtiff): bugs=AAH020, cves=CVE-2016-3658, asan=DEADLYSIGNAL
