# Support-Count Baseline Summary

## Primary Metrics
- `HighRisk@5=1`
- `HighRisk@10=1`
- `NDCG@5=0.3392`
- `NDCG@10=0.2201`
- `Rank-to-First-HighRisk=1`
- `Effort-to-First-HighRisk=7.92`

## Top-10 Findings
- `1`. `wasm3::finding::30113371` risk=3 score=741.0 support=`741` report=`exact`
- `2`. `binaryen::finding::86588299` risk=0 score=682.0 support=`682` report=`project`
- `3`. `binaryen::finding::56457462` risk=0 score=498.0 support=`498` report=`exact`
- `4`. `ChaiScript::finding::11793711` risk=0 score=345.0 support=`345` report=`project`
- `5`. `janet::finding::14567654` risk=0 score=214.0 support=`214` report=`project`
- `6`. `mruby::finding::69853620` risk=0 score=147.0 support=`147` report=`project`
- `7`. `micropython::finding::13571076` risk=0 score=145.0 support=`145` report=`none`
- `8`. `binaryen::finding::79565612` risk=0 score=96.0 support=`96` report=`exact`
- `9`. `LIEF::finding::52058062` risk=0 score=75.0 support=`75` report=`project`
- `10`. `LIEF::finding::92178408` risk=0 score=75.0 support=`75` report=`project`
