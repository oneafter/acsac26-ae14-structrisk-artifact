# MAGMA full-inventory NVD severity summary

- Distinct CVEs in MAGMA inventory: 125
- HIGH or CRITICAL under preferred NVD CVSS: 84
- Severity counts: CRITICAL=21, HIGH=63, LOW=1, MEDIUM=40
- CVSS metric versions used: v2=14, v3.0=66, v3.1=45
