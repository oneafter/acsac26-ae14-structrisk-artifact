# MAGMA PoC Package Coverage

## Packages

| Package | Files | Matched | Bug IDs | Projects |
| --- | ---: | ---: | ---: | ---: |
| `poc_afl.tar.gz` | 21089 | 20752 | 26 | 7 |
| `poc_aflfast.tar.gz` | 33180 | 32550 | 26 | 7 |
| `poc_aflplusplus.tar.gz` | 35182 | 35079 | 28 | 7 |
| `poc_aflplusplus_lto.tar.gz` | 31624 | 31560 | 26 | 6 |
| `poc_honggfuzz.tar.gz` | 6715 | 5315 | 36 | 7 |
| `poc_moptafl.tar.gz` | 70610 | 67558 | 45 | 7 |
| `poc_angora.tar.gz` | 82840 | 82835 | 8 | 2 |
| `poc_instrim.tar.gz` | 11117 | 10995 | 19 | 6 |

## Union

- Archive files scanned: `292357`
- Matched PoC files: `286644`
- Distinct parsed bug IDs: `49`
- Legacy inventory coverage: `49/120` bug IDs, `45` CVEs, `31` HIGH-or-higher bug IDs
- Current HTML inventory coverage: `0/138` bug IDs

Covered legacy bug IDs: `AAH001, AAH003, AAH007, AAH008, AAH009, AAH010, AAH013, AAH014, AAH015, AAH016, AAH017, AAH020, AAH022, AAH024, AAH025, AAH026, AAH029, AAH032, AAH035, AAH037, AAH041, AAH042, AAH043, AAH045, AAH046, AAH048, AAH049, AAH050, AAH052, AAH055, AAH056, JCH201, JCH207, JCH209, JCH210, JCH212, JCH215, JCH216, JCH223, JCH226, JCH227, JCH228, JCH229, JCH232, MAE008, MAE014, MAE016, MAE104, MAE115`
